#ifndef SERVER_H
#define SERVER_H
#include"torrent.h"
#include"game.h"
#include"film.h"
#include"software.h"
#include<iostream>

class Server{

	vector<Torrent> torrents;
	vector<Game> games;
	vector<Film> films;
	vector<Software> software;
	vector<string> users;

	void set_users(vector<string> users);
	void set_torrents(vector<Torrent> torrents);
	void set_games(vector<Game> games);
	void set_films(vector<Film> films);
	void set_software(vector<Software> software);
	
public: 

	Server(vector<Torrent> torrents, vector<Game> games, vector<Film	> films, vector<Software> software, vector<string> users){
		this->set_torrents(torrents);
		this->set_games(games);
		this->set_films(films);
		this->set_software(software);
		this->set_users(users);
	}
	
	Server(const Server &other){
		this->set_torrents(other.get_torrents());
		this->set_games(other.get_games());
		this->set_films(other.get_films());
		this->set_software(other.get_software());
		this->set_users(other.get_users());
	}
	
	bool search_user(string name);
	
	vector<Torrent> get_torrents() const;
	vector<Game> get_games() const;
	vector<Film> get_films() const;
	vector<Software> get_software() const;
	vector<string> get_users() const;
	
	vector<Torrent> search_name(string name);
	vector<Game> search_games(char maturity);
	vector<Film> search_films(string producer);
	vector<Software> search_software(int major);
	
	void add_torrent(string user, Torrent &torrent);
	void add_torrent(string user, Game &game);
	void add_torrent(string user, Film &film);
	void add_torrent(string user, Software &software);
};

#endif

#include"game.h"

using namespace std;

void Game::set_platform(string platform){

	if(platform == ""){
		throw exception();
	}

	this->platform = platform;
}

void Game::set_maturity(char maturity){

	if(maturity != 'E' && maturity != 'M' && maturity != 'P'){
		throw exception();
	}

	this->maturity = maturity;
}

string Game::get_platform() const{
	return this->platform;
}

char Game::get_maturity() const{
	return this->maturity;
}

string Game::toString(){
	string group;
	
	if(maturity == 'E'){
		group = "everyone\n";
	
	}else if(maturity == 'M'){
		group = "over 15 years old only\n";
	
	}else{
		group = "adults only\n";
	}
	

	return "Torrent title: " + get_title() +
		   "\nTorrent size: " + to_string(get_size()) + " bytes" +
		   "\nUploaded by: " + get_uploader() +
		   "\nDownloaded: " + to_string(get_downloads()) + " times"
		   "\nGaming platform: " + platform +
		   "\nAppropriate for: " + group + "\n";
}

void Game::sort_titles(vector<Game> &games){

	if(games.size() < 2){
		throw exception();
	}

	for(int i = 0; i < games.size() - 1; i++){
		
		for(int j = i + 1; j < games.size(); j++){
		
			if(games[i].get_title().compare(games[j].get_title()) > 0){
				Game third = games[i];	
				games[i] = games[j];
				games[j] = third;
			}
		}	
	}
}

void Game::sort_sizes(vector<Game> &games){

	if(games.size() < 2){
		throw exception();
	}

	for(int i = 0; i < games.size() - 1; i++){
		
		for(int j = i + 1; j < games.size(); j++){
		
			if(games[i].get_size() > games[j].get_size()){
				Game third = games[i];	
				games[i] = games[j];
				games[j] = third;
			}
		}	
	}
}

void Game::sort_uploaders(vector<Game> &games){

	if(games.size() < 2){
		throw exception();
	}

	for(int i = 0; i < games.size() - 1; i++){
		
		for(int j = i + 1; j < games.size(); j++){
		
			if(games[i].get_uploader().compare(games[j].get_uploader()) > 0){
				Game third = games[i];	
				games[i] = games[j];
				games[j] = third;
			}
		}	
	}
}

void Game::sort_downloads(vector<Game> &games){

	if(games.size() < 2){
		throw exception();
	}

	for(int i = 0; i < games.size() - 1; i++){
		
		for(int j = i + 1; j < games.size(); j++){
		
			if(games[i].get_downloads() > games[j].get_downloads()){
				Game third = games[i];	
				games[i] = games[j];
				games[j] = third;
			}
		}	
	}
}

void Game::sort_platforms(vector<Game> &torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_platform().compare(torrents[j].get_platform()) > 0){
				Game third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

void Game::sort_maturity(vector<Game> &torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_maturity() > torrents[j].get_maturity()){
				Game third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

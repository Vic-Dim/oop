#ifndef GAME_H
#define GAME_H
#include"torrent.h"

using namespace std;

class Game : public Torrent{

	string platform;
	char maturity;

	void set_platform(string platform);	
	void set_maturity(char c);

public:

	Game(string title, int size, string uploaded_by, int downloads, string platform, char maturity) : 
	Torrent(title, size, uploaded_by, downloads){
		this->set_platform(platform);
		this->set_maturity(maturity);
	}
	
	Game(const Game &other) : Torrent(other.get_title(), other.get_size(), other.get_uploader(), other.get_downloads()){
		this->set_platform(other.get_platform());
		this->set_maturity(other.get_maturity());
	}

	string get_platform() const;
	char get_maturity() const;
	
	string toString();
	
	static void sort_titles(vector<Game> &games);
	static void sort_sizes(vector<Game> &games);
	static void sort_uploaders(vector<Game> &games);
	static void sort_downloads(vector<Game> &games);
	static void sort_platforms(vector<Game> &torrents);
	static void sort_maturity(vector<Game> &torrents);
};

#endif

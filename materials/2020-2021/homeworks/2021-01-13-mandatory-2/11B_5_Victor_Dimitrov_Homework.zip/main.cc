#include<iostream>
#include"server.h"
#include<fstream>
#include<sstream>

using namespace std;

vector<Torrent> create_torrents(){

	Torrent t1 = {"Torrent1", 5, "bot1", 0};
	Torrent t2 = {"Torrent2", 7, "bot2", 0};
	Torrent t3 = {"Torrent3", 9, "johnny_bravo", 1};		
	Torrent t4 = {"A book", 34894, "Saidan", 7};	
	Torrent t5 = {"An app", 10000, "deleted_user", 71};
	Torrent t6 = {"Another app", 4846, "Prrr", 788};
	Torrent t7 = {"Manga", 700, "w3aboo", 0}; 
	
	vector<Torrent> res;
	
	res.push_back(t1);
	res.push_back(t2);
	res.push_back(t3);
	res.push_back(t4);
	res.push_back(t5);
	res.push_back(t6);
	res.push_back(t7);
	
	return res;
}

vector<Game> create_games(){

	Game g1 = {"World of Warcraft: Wrath of The Lich King", 50000000, "Blizzard", 8684648, "Windows", 'E'};
	Game g2 = {"World of Warcraft: Legion", 75000000, "Blizzard", 7651337, "Windows", 'E'};
	Game g3 = {"World of Warcraft: Classic", 30000000, "Blizzard", 4751320, "Windows", 'E'};
	Game g4 = {"World of Warcraft: Shadowlands", 80000000, "Blizzard", 6876100, "Windows", 'E'};
	Game g5 = {"Warcraft III", 10000000, "Blizzard", 10578910, "Windows", 'E'};
	Game g6 = {"Age of Empires II: The Age of Kings", 15156065, "Xbox Game Studios", 10545780, "Windows", 'M'};
	Game g7 = {"Age of Empires II: Definitive Edition", 45115083, "Xbox Game Studios", 25047650, "Windows", 'M'};
	Game g8 = {"Age of Empires III", 30871879, "Microsoft Game Studios", 15895187, "Windows", 'M'};
	Game g9 = {"Age of Empires III: Warchiefs", 40684136, "Microsoft Game Studios", 18987230, "Windows", 'M'};
	Game g10 = {"Age of Empires III: Asian Dynasties", 50359746, "Microsoft Game Studios", 21369862, "Windows", 'M'};
	Game g11 = {"Counter-Strike 1.6", 10326988, "Valve", 40963899, "Windows", 'P'};

	vector<Game> res;

	res.push_back(g1);
	res.push_back(g2);
	res.push_back(g3);
	res.push_back(g4);
	res.push_back(g5);
	res.push_back(g6);
	res.push_back(g7);
	res.push_back(g8);
	res.push_back(g9);
	res.push_back(g10);
	res.push_back(g11);
	
	return res;
}

vector<Film> create_films(){

	Film f1 = {"Indiana Jones: Raiders of the Lost Ark", 84813549, "Jones Fan", 1949, "Steven Spielberg", 115, "English"};
	Film f2 = {"Indiana Jones and The Temple of Doom", 78913559, "Jones Fan", 533, "Steven Spielberg", 118, "English"};
	Film f3 = {"Indiana Jones and the Last Crusade", 6697784, "Jones Fan", 7800, "Steven Spielberg", 127, "English"};
	Film f4 = {"Indiana Jones and the Kingdom of the Crystal Skull", 77789171, "Jones Fan", 2400, "Steven Spielberg", 122, "English"};
	Film f5 = {"John Wick", 102597889, "hitman", 87946, "Chad Stahelski", 102, "German"};

	vector<Film> res;
	
	res.push_back(f1);
	res.push_back(f2);
	res.push_back(f3);
	res.push_back(f4);
	res.push_back(f5);
		
	return res;
}

vector<Software> create_software(){

	vector<int> v1, v2, v3, v4, v5;
	v1.push_back(1);
	v1.push_back(0);
	v1.push_back(1);
	v2.push_back(4);
	v2.push_back(2);
	v2.push_back(0);
	v3.push_back(1);
	v3.push_back(0);
	v3.push_back(13);
	v4.push_back(2);
	v4.push_back(0);
	v4.push_back(7);
	v5.push_back(0);
	v5.push_back(1);
	v5.push_back(12);

	Software s1 = {"Software1", 876146, "publisher", 0, "Company1", "Android", v1};
	Software s2 = {"Software2", 7946, "publisher", 7, "Company1", "iOS", v2};
	Software s3 = {"Software3", 8791989, "publisher", 14, "Supreme Company", "Windows", v3};
	Software s4 = {"Software4", 98794, "publisher", 19000, "Utility", "Windows", v4};
	Software s5 = {"Software5", 87990, "publisher", 169, "Company3", "Android", v5};

	vector<Software> res;	

	res.push_back(s1);
	res.push_back(s2);
	res.push_back(s3);
	res.push_back(s4);
	res.push_back(s5);
	
	return res;
}

vector<string> create_users(){

	vector<string> res;
	
	res.push_back("Saidan");
	res.push_back("Creeping Death");
	res.push_back("W3aboo");
	res.push_back("demon_slayer69");
	res.push_back("user");
	res.push_back("deleted user");
	res.push_back("toxic kiddo");
	res.push_back("Disposable Hero");
	res.push_back("maggot");
	
	return res;
}

int main(){

	vector<Torrent> torrents;
	vector<Game> games;
	vector<Film> films;
	vector<Software> software;
	vector<string> users;
	

	try{
		users = create_users();
		torrents = create_torrents();
		games = create_games();
		films = create_films();
		software = create_software();

		Server s = {torrents, games, films, software, users};

		Torrent torrent = torrents[0];
		Game game = games[0];
		Film film = films[0];
		Software soft = software[0];
		
		s.add_torrent("Saidan", torrent);
		s.add_torrent("Saidan", game);
		s.add_torrent("Saidan", film);
		s.add_torrent("Saidan", soft);
		
		torrents = s.get_torrents();
		games = s.get_games();
		films = s.get_films();
		software = s.get_software();
	
		Torrent::sort_titles(torrents);
		Game::sort_platforms(games);
		Film::sort_durations(films);
		Software::sort_OS(software);
	
		cout << "----- Torrents sorted by title ------" << endl;
	
		for(int i = 0; i < torrents.size(); i++){
			cout << torrents[i].toString() << endl;
		}
		
		vector<Game> maturity_res = s.search_games('E');
		vector<Software> major_res = s.search_software(1);
		
		cout << "\n\n\n\n";
		cout << "----- Games with certain maturity level -----" << endl;
		cout << endl;
		
		for(int i = 0; i < maturity_res.size(); i++){
			cout << maturity_res[i].toString() << endl;
		}
		
		cout << "\n\n\n\n";
		cout << "----- Games sorted by platforms -----" << endl;
		cout << endl;
		
		for(int i = 0; i < games.size(); i++){
			cout << games[i].toString() << endl;
		}
		
		cout << "\n\n\n\n";
		cout << "----- Games filtered by producer -----" << endl;
		vector<Film> producer_res = s.search_films("Gary Kurtz");
		
		cout << "\n\n\n\n";
		cout << "----- Films sorted by duration -----" << endl;
		cout << endl;
		
		for(int i = 0; i < films.size(); i++){
			cout << films[i].toString() << endl;
		}
		
		cout << "\n\n\n\n";
		cout << "----- Software filtered by major -----" << endl;
		cout << endl;

		for(int i = 0; i < major_res.size(); i++){
			cout << major_res[i].toString() << endl;
		}
		
		cout << "\n\n\n\n";
		cout << "----- Software sorted by OS -----" << endl;
		cout << endl;
		
		for(int i = 0; i < software.size(); i++){
			cout << software[i].toString() << endl;
		}
		
	}catch(exception ex){
		cout << "Something went wrong..." << endl;
	}
	
	return 0;
}

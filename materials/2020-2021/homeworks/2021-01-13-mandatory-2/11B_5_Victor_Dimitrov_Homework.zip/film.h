#ifndef FILM_H
#define FILM_H
#include"torrent.h"

class Film : public Torrent{

	string producer;
	int duration;
	string language;
	
	void set_producer(string producer);
	void set_duration(int duration);
	void set_language(string language);

public:

	Film(string title, int size, string uploaded_by, int downloads, string producer, int duration, string language) :
	Torrent(title, size, uploaded_by, downloads){
		this->set_producer(producer);
		this->set_duration(duration);
		this->set_language(language);
	}

	Film(const Film &other) : Torrent(other.get_title(), other.get_size(), other.get_uploader(), other.get_downloads()){
		this->set_producer(other.get_producer());
		this->set_duration(other.get_duration());
		this->set_language(other.get_language());
	}
	
	string get_producer() const;
	int get_duration() const;
	string get_language() const;
	
	string toString();
	
	static void sort_titles(vector<Film> &torrents);
	static void sort_sizes(vector<Film> &torrents);
	static void sort_uploaders(vector<Film> &torrents);
	static void sort_downloads(vector<Film> &torrents);
	static void sort_producers(vector<Film> torrents);
	static void sort_durations(vector<Film> torrents);
	static void sort_language(vector<Film> torrents);
};

#endif

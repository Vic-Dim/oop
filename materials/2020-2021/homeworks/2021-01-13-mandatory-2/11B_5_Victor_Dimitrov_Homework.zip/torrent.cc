#include"torrent.h"
#include<exception>

void Torrent::set_title(string title){

	if(title == ""){
		throw exception();
	} 

	this->title = title;
}

void Torrent::set_size(int size){

	if(size <= 0){
		throw exception();
	}

	this->size = size;
}

void Torrent::set_uploader(string uploader){

	if(uploader == ""){
		throw exception();
	}

	this->uploaded_by = uploader;
}
	
void Torrent::set_downloads(int downloads){

	if(downloads < 0){
		throw exception();
	}

	this->downloads = downloads;
}

string Torrent::get_title() const{
	return this->title;
}

int Torrent::get_size() const{
	return this->size;
}

string Torrent::get_uploader() const{
	return this->uploaded_by;
}

int Torrent::get_downloads() const{
	return this->downloads;
}

string Torrent::toString(){

	return "Torrent title: " + title +
		   "\nTorrent size: " + to_string(size) + " bytes" +
		   "\nUploaded by: " + uploaded_by +
		   "\nDownloaded: " + to_string(downloads) + " times.\n";
}

void Torrent::sort_titles(vector<Torrent> &torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_title().compare(torrents[j].get_title()) > 0){
				Torrent third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

void Torrent::sort_sizes(vector<Torrent> &torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_size() > torrents[j].get_size()){
				Torrent third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

void Torrent::sort_uploaders(vector<Torrent> &torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_uploader().compare(torrents[j].get_uploader()) > 0){
				Torrent third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

void Torrent::sort_downloads(vector<Torrent> &torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_downloads() > torrents[j].get_downloads()){
				Torrent third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

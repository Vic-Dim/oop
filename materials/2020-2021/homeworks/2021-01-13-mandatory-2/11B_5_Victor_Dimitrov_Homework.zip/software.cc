#include"software.h"

void Software::set_manufacturer(string manufacturer){

	if(manufacturer == ""){
		throw exception();
	}

	this->manufacturer = manufacturer;
}
	
void Software::set_OS(string OS){

	if(OS == ""){
		throw exception();
	}

	this->OS = OS;
}
	
void Software::set_version(vector<int> version){

	for(int i = 0; i < 3; i++){
		
		if(version[i] < 0){
			throw exception();
		}
	}

	for(int i = 0; i < 3; i++){
		this->version.push_back(version[i]);
	}
} 

string Software::get_manufacturer() const{
	return this->manufacturer;
}

string Software::get_OS() const{
	return this->OS;
}

vector<int> Software::get_version() const{
	return this->version;
}

string Software::toString(){

	return "Torrent title: " + get_title() +
		   "\nTorrent size: " + to_string(get_size()) + " bytes" +
		   "\nUploaded by: " + get_uploader() +
		   "\nDownloaded: " + to_string(get_downloads()) + " times"
		   "\nManufacturer: " + manufacturer +
		   "\nOS: " + OS +
		   "\nVersion: " + to_string(version[0]) + "." + to_string(version[1]) + "." + to_string(version[2]) + "\n";
}

void Software::sort_titles(vector<Software> &films){

	if(films.size() < 2){
		throw exception();
	}

	for(int i = 0; i < films.size() - 1; i++){
		
		for(int j = i + 1; j < films.size(); j++){
		
			if(films[i].get_title().compare(films[j].get_title()) > 0){
				Software third = films[i];	
				films[i] = films[j];
				films[j] = third;
			}
		}	
	}
}

void Software::sort_sizes(vector<Software> &software){

	if(software.size() < 2){
		throw exception();
	}

	for(int i = 0; i < software.size() - 1; i++){
		
		for(int j = i + 1; j < software.size(); j++){
		
			if(software[i].get_size() > software[j].get_size()){
				Software third = software[i];	
				software[i] = software[j];
				software[j] = third;
			}
		}	
	}
}

void Software::sort_uploaders(vector<Software> &software){

	if(software.size() < 2){
		throw exception();
	}

	for(int i = 0; i < software.size() - 1; i++){
		
		for(int j = i + 1; j < software.size(); j++){
		
			if(software[i].get_uploader().compare(software[j].get_uploader()) > 0){
				Software third = software[i];	
				software[i] = software[j];
				software[j] = third;
			}
		}	
	}
}

void Software::sort_downloads(vector<Software> &software){

	if(software.size() < 2){
		throw exception();
	}

	for(int i = 0; i < software.size() - 1; i++){
		
		for(int j = i + 1; j < software.size(); j++){
		
			if(software[i].get_downloads() > software[j].get_downloads()){
				Software third = software[i];	
				software[i] = software[j];
				software[j] = third;
			}
		}	
	}
}

void Software::sort_manufacturers(vector<Software> &torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_manufacturer().compare(torrents[j].get_manufacturer()) > 0){
				Software third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}
	
void Software::sort_OS(vector<Software> &torrents){
	
	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_OS().compare(torrents[j].get_OS()) > 0){
				Software third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}	
	
}

void Software::sort_versions(vector<Software> &torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_version()[0] > torrents[j].get_version()[0]){
				Software third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
				
			}else{
				
				if(torrents[i].get_version()[1] > torrents[j].get_version()[1]){
					Software third = torrents[i];	
					torrents[i] = torrents[j];
					torrents[j] = third;
				
				}else{
					
					if(torrents[i].get_version()[2] > torrents[j].get_version()[2]){
						Software third = torrents[i];	
						torrents[i] = torrents[j];
						torrents[j] = third;
					}
				}
			}
		}	
	}
}

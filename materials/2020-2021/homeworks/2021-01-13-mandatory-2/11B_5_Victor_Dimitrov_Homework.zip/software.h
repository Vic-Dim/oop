#ifndef SOFTWARE_H
#define SOFTWARE_H
#include"torrent.h"

class Software : public Torrent{

	string manufacturer;
	string OS;
	vector<int> version;

	void set_manufacturer(string manufacturer);
	void set_OS(string OS);
	void set_version(vector<int> version);
	
public:

	Software(string title, int size, string uploaded_by, int downloads, string manufacturer, string OS, vector<int> version) : 
	Torrent(title, size, uploaded_by, downloads){
		this->set_manufacturer(manufacturer);
		this->set_OS(OS);
		this->set_version(version);
	}	
	
	Software(const Software &other) : Torrent(other.get_title(), other.get_size(), other.get_uploader(), other.get_downloads()){
		this->set_manufacturer(other.get_manufacturer());
		this->set_OS(other.get_OS());
		this->set_version(other.get_version());
	}
	
	string get_manufacturer() const;
	string get_OS() const;
	vector<int> get_version() const;
	
	string toString();
	
	static void sort_titles(vector<Software> &torrents);
	static void sort_sizes(vector<Software> &torrents);
	static void sort_uploaders(vector<Software> &torrents);
	static void sort_downloads(vector<Software> &torrents);
	static void sort_manufacturers(vector<Software> &torrents);
	static void sort_OS(vector<Software> &torrents);
	static void sort_versions(vector<Software> &torrents);
};

#endif

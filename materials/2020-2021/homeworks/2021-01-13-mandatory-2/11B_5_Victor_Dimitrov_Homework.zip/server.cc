#include"server.h"

using namespace std;

void Server::set_torrents(vector<Torrent> torrents){

	for(int i = 0; i < torrents.size(); i++){
		this->torrents.push_back(torrents[i]);
	}
}

void Server::set_games(vector<Game> games){

	for(int i = 0; i < games.size(); i++){
		this->games.push_back(games[i]);
	}
}

void Server::set_films(vector<Film> films){

	for(int i = 0; i < films.size(); i++){
		this->films.push_back(films[i]);
	}
}

void Server::set_software(vector<Software> software){

	for(int i = 0; i < software.size(); i++){
		this->software.push_back(software[i]);
	}
}

void Server::set_users(vector<string> users){

	for(int i = 0; i < users.size(); i++){
	
		if(users[i] == ""){
			throw exception();
		}
	
		this->users.push_back(users[i]);
	}
}

bool Server::search_user(string name){

	for(int i = 0; i < users.size(); i++){
	
		if(users[i].compare(name) == 0){
			return true;
		}
	}

	return false;
}
	
vector<Torrent> Server::get_torrents() const{
	return this->torrents;	
}

vector<Game> Server::get_games() const{
	return this->games;
}
	
vector<Film> Server::get_films() const{
	return this->films;
}

vector<Software> Server::get_software() const{
	return this->software;
}

vector<string> Server::get_users() const{
	return this->users;
}

vector<Torrent> Server::search_name(string name){

	vector<Torrent> res;

	for(int i = 0; i < torrents.size(); i++){
		
		if(torrents[i].get_title().compare(name) == 0){
			res.push_back(torrents[i]);
		}
	}

	if(res.size() == 0){
		cout << "Sorry, no torrents found" << endl;
	}

	return res;
}

vector<Game> Server::search_games(char maturity){

	vector<Game> res;

	for(int i = 0; i < games.size(); i++){
		
		if(games[i].get_maturity() == maturity){
			res.push_back(games[i]);
		}
	}

	if(res.size() == 0){
		cout << "Sorry, no games found" << endl;
	}

	return res;
}

vector<Film> Server::search_films(string producer){

	vector<Film> res;

	for(int i = 0; i < films.size(); i++){
		
		if(films[i].get_producer().compare(producer) == 0){
			res.push_back(films[i]);
		}
	}

	if(res.size() == 0){
		cout << "Sorry, no films found" << endl;
	}

	return res;
}

vector<Software> Server::search_software(int major){

	vector<Software> res;

	for(int i = 0; i < software.size(); i++){
		
		if(software[i].get_version()[0] == major){
			res.push_back(software[i]);
		}
	}
	
	if(res.size() == 0){
		cout << "Sorry, no software found" << endl;
	}

	return res;
}

void Server::add_torrent(string user, Torrent &torrent){

	if(!this->search_user(user)){
		cout << "Invalid user!" << endl;
		return;
	}
	
	torrents.push_back(torrent);
}

void Server::add_torrent(string user, Game &game){

	if(!this->search_user(user)){
		cout << "Invalid user!" << endl;
		return;
	}
	
	games.push_back(game);
	torrents.push_back(game);
}

void Server::add_torrent(string user, Film &film){

	if(!this->search_user(user)){
		cout << "Invalid user!" << endl;
		return;
	}
	
	films.push_back(film);
	torrents.push_back(film);
}

void Server::add_torrent(string user, Software &software){

	if(!this->search_user(user)){
		cout << "Invalid user!" << endl;
		return;
	}
	
	this->software.push_back(software);
	torrents.push_back(software);
}

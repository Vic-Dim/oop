#include"film.h"

void Film::set_producer(string producer){

	if(producer == ""){
		throw exception();
	}

	this->producer = producer;
}

void Film::set_duration(int duration){

	if(duration <= 0){
		throw exception();
	}

	this->duration = duration;
}

void Film::set_language(string language){

	if(language == ""){
		throw exception();
	}

	this->language = language;
}

string Film::get_producer() const{
	return this->producer;
}

int Film::get_duration() const{
	return this->duration;
}

string Film::get_language() const{
	return this->language;
}

string Film::toString(){

	return "Torrent title: " + get_title() +
		   "\nTorrent size: " + to_string(get_size()) + " bytes" +
		   "\nUploaded by: " + get_uploader() +
		   "\nDownloaded: " + to_string(get_downloads()) + " times"
		   "\nProducer: " + producer +
		   "\nDuration: " + to_string(duration) + " minutes" +
		   "\nLanguage: " + language + "\n";
}

void Film::sort_titles(vector<Film> &films){

	if(films.size() < 2){
		throw exception();
	}

	for(int i = 0; i < films.size() - 1; i++){
		
		for(int j = i + 1; j < films.size(); j++){
		
			if(films[i].get_title().compare(films[j].get_title()) > 0){
				Film third = films[i];	
				films[i] = films[j];
				films[j] = third;
			}
		}	
	}
}

void Film::sort_sizes(vector<Film> &films){

	if(films.size() < 2){
		throw exception();
	}

	for(int i = 0; i < films.size() - 1; i++){
		
		for(int j = i + 1; j < films.size(); j++){
		
			if(films[i].get_size() > films[j].get_size()){
				Film third = films[i];	
				films[i] = films[j];
				films[j] = third;
			}
		}	
	}
}

void Film::sort_uploaders(vector<Film> &films){

	if(films.size() < 2){
		throw exception();
	}

	for(int i = 0; i < films.size() - 1; i++){
		
		for(int j = i + 1; j < films.size(); j++){
		
			if(films[i].get_uploader().compare(films[j].get_uploader()) > 0){
				Film third = films[i];	
				films[i] = films[j];
				films[j] = third;
			}
		}	
	}
}

void Film::sort_downloads(vector<Film> &films){

	if(films.size() < 2){
		throw exception();
	}

	for(int i = 0; i < films.size() - 1; i++){
		
		for(int j = i + 1; j < films.size(); j++){
		
			if(films[i].get_downloads() > films[j].get_downloads()){
				Film third = films[i];	
				films[i] = films[j];
				films[j] = third;
			}
		}	
	}
}

void Film::sort_producers(vector<Film> torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_producer().compare(torrents[j].get_producer()) > 0){
				Film third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

void Film::sort_durations(vector<Film> torrents){
	
	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_duration() > torrents[j].get_duration()){
				Film third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

void Film::sort_language(vector<Film> torrents){

	if(torrents.size() < 2){
		throw exception();
	}

	for(int i = 0; i < torrents.size() - 1; i++){
		
		for(int j = i + 1; j < torrents.size(); j++){
		
			if(torrents[i].get_language().compare(torrents[j].get_language()) > 0){
				Film third = torrents[i];	
				torrents[i] = torrents[j];
				torrents[j] = third;
			}
		}	
	}
}

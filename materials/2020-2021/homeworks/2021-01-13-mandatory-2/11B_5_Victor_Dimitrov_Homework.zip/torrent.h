#ifndef TORRENT_H
#define TORRENT_H
#include<string>
#include<vector>

using namespace std;

class Torrent{

	string title;
	int size;
	string uploaded_by;	
	int downloads;

	void set_title(string title);
	void set_size(int size);
	void set_uploader(string uploader);
	void set_downloads(int donwloads);
	
public:	

	Torrent(string title, int size, string uploaded_by, int downloads){
		this->set_title(title);
		this->set_size(size);
		this->set_uploader(uploaded_by);
		this->set_downloads(downloads);
	}

	Torrent(const Torrent &other){
		this->set_title(other.get_title());
		this->set_size(other.get_size());
		this->set_uploader(other.get_uploader());
		this->set_downloads(other.get_downloads());
	}

	static void sort_titles(vector<Torrent> &torrents);
	static void sort_sizes(vector<Torrent> &torrents);
	static void sort_uploaders(vector<Torrent> &torrents);
	static void sort_downloads(vector<Torrent> &torrents);

	string get_title() const;
	int get_size() const;
	string get_uploader() const;
	int get_downloads() const;
	
	virtual string toString();
};

#endif
